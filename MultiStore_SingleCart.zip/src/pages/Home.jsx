import React from "react";

const products = [
  { id: 1, name: "Amazon Product 1", price: 100, store: "Amazon" },
  { id: 2, name: "Flipkart Product 1", price: 90, store: "Flipkart" },
];

function Home({ addToCart }) {
  return (
    <div>
      <h2>Available Products</h2>
      {products.map((product) => (
        <div key={product.id} className="product">
          <p>{product.name} - ${product.price} ({product.store})</p>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      ))}
    </div>
  );
}

export default Home;