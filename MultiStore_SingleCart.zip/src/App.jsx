import React, { useState } from "react";
import Home from "./pages/Home";
import Cart from "./pages/Cart";
import "./App.css";

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="App">
      <h1>Multi-Store Single Cart</h1>
      <Home addToCart={addToCart} />
      <Cart cart={cart} />
    </div>
  );
}

export default App;